﻿using AutoMapper;
using HotelManagement_Project.Model.DTO;
using HotelManagement_Project.Repositories;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace HotelManagement_Project.Controllers
{
   
    [ApiController]
    [Route("Inventory")]
   
    public class InventoryController : Controller
    {
        private readonly IInventoryRepositorycs _inventoryRepository;

        private readonly IMapper Mapper;

        //constructor
        public InventoryController(IInventoryRepositorycs inventoryRepository, IMapper mapper)
        {
            this._inventoryRepository = inventoryRepository;

            this.Mapper = mapper;
        }


        //GetAll
        [HttpGet]
        
        public async Task<IActionResult> GetAllInventoryAsync()
        {
            var inventory = await _inventoryRepository.GetAllAsync();

            // Auto MApper

            var inventoryDTO = Mapper.Map<List<Model.DTO.Inventory>>(inventory);

            return Ok(inventoryDTO);
        }


        //GetByID
        [HttpGet]
        [Route("{id:guid}")]
        [ActionName("GetInventoryAsync")]
       
        public async Task<IActionResult> GetInventoryAsync(Guid id)
        {
            var inventorym = await _inventoryRepository.GetAsync(id);

            if (inventorym == null)
            {
                return NotFound();
            }

            var inventoryDTO = Mapper.Map<Model.DTO.Inventory>(inventorym);

            return Ok(inventoryDTO);
        }


        //Add
        [HttpPost]
        
        public async Task<IActionResult> AddInventoryAsync(Model.DTO.AddInventoryRequest addinventoryRequest)
        {
            
            // first convert Request(DTO) to domain model
            var inventory = new Model.Domain.Inventory()
            {
                Inventory_Name = addinventoryRequest.Inventory_Name,

                quantity = addinventoryRequest.quantity,

            };

            //Pass details to Repository
            inventory = await _inventoryRepository.AddAsync(inventory);

            //Convert back to DTO

            var inventoryDTO = new Model.DTO.Inventory()
            {

                Inventory_Name = inventory.Inventory_Name,

                quantity = inventory.quantity

            };

            return CreatedAtAction(nameof(GetInventoryAsync), new { id = inventoryDTO.Inventory_Id }, inventoryDTO);

        }


        //Delete
        [HttpDelete]
        [Route("{id:guid}")]
        
        public async Task<IActionResult> DeleteInventoryAsync(Guid id)
        {
           

            var inventory = await _inventoryRepository.DeleteAsync(id);

           
            if (inventory == null)
            {
                return NotFound();
            }
            //convert response back to DTO
            var inventoryDTO = new Model.DTO.Inventory()
            {
                Inventory_Name = inventory.Inventory_Name,

                quantity = inventory.quantity


            };

            //return Ok response
            return Ok(inventoryDTO);

        }


        //Update
        [HttpPut]
        [Route("{id:guid}")]
       
        public async Task<IActionResult> UpdateInventoryAsync([FromRoute] Guid id, 
            [FromBody] Model.DTO.UpdateInventoryRequest updateInventoryRequest)
        {
           

            var inventory = new Model.Domain.Inventory()
            {
                Inventory_Name = updateInventoryRequest.Inventory_Name,

                quantity = updateInventoryRequest.quantity,


            };


            //update  using repository
            inventory = await _inventoryRepository.UpdateAsync(id, inventory);

           
            if (inventory == null)
            {
                return NotFound();
            }

            //Convert Domain back to DTO
            var inventoryDTO = new Model.DTO.Inventory
            {
                Inventory_Name = inventory.Inventory_Name,

                quantity = inventory.quantity

            };

           

            return Ok(inventoryDTO);
        }


        
    }

}




