﻿using AutoMapper;
using HotelManagement_Project.Model.DTO;
using HotelManagement_Project.Repositories;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace HotelManagement_Project.Controllers
{

    [ApiController]
    [Route("Reservation")]
    public class ReservationController : Controller
    {
        private readonly IReservationRepository _reservatioRepository;
        private readonly IMapper Mapper;
        private readonly IGuestRepository guestRepository;
        private readonly IRoomRepository roomRepository;


        //constructor
        public ReservationController(IReservationRepository reservationRepository, IMapper mapper, 
            IGuestRepository guestRepository,IRoomRepository roomRepository)
        {
            this._reservatioRepository = reservationRepository;

            this.Mapper = mapper;
            this.guestRepository = guestRepository;
            this.roomRepository = roomRepository;
        }


        //GetAll
        [HttpGet]
        
        //[Authorize(Roles = "receptionist,manager,owner")]
        public async Task<IActionResult> GetAllReservationAsync()
        {
            var reservation = await _reservatioRepository.GetAllAsync();

            // Auto MApper

            var reservationDTO = Mapper.Map<List<Model.DTO.Reservation>>(reservation);

            return Ok(reservationDTO);
        }


        //GetByID
        [HttpGet]
        [Route("{id:guid}")]
        [ActionName("GetReservationAsync")]
        
        //[Authorize(Roles = "receptionist,manager")]
        public async Task<IActionResult> GetReservationAsync(Guid id)
        {
            var reservation = await _reservatioRepository.GetAsync(id);

            if (reservation == null)
            {
                return NotFound();
            }

            var reservationDTO = Mapper.Map<Model.DTO.Reservation>(reservation);

            return Ok(reservationDTO);
        }

        //Add
        [HttpPost]
        
      // [Authorize(Roles = "receptionist,manager,owner")]
        public async Task<IActionResult> AddReservationAsync(Model.DTO.AddReservationRequest addReservationRequest)
        {
            
            var reservation = new Model.Domain.Reservation()
            {
                Check_in = addReservationRequest.Check_in,

                Check_out = addReservationRequest.Check_out,

                status = addReservationRequest.status,

                Guest_Id = addReservationRequest.Guest_Id,

                no_of_adults = addReservationRequest.no_of_adults,

                no_of_children = addReservationRequest.no_of_children,

                no_of_nights = addReservationRequest.no_of_nights,

                Room_id = addReservationRequest.Room_id

              };

            //Pass details to Repository
            reservation = await _reservatioRepository.AddAsync(reservation);

            //Convert back to DTO

            var reservationDTO = new Model.DTO.Reservation
            {
                reservation_id = reservation.reservation_id,

                no_of_adults = reservation.no_of_adults,

                no_of_children = reservation.no_of_children,

                Check_out = reservation.Check_out,

                Check_in = reservation.Check_in,

                status = reservation.status,

                no_of_nights = reservation.no_of_adults,

                Guest_Id = reservation.Guest_Id,

                Room_id = reservation.Room_id

                };

            return CreatedAtAction(nameof(GetReservationAsync), new { id = reservationDTO.reservation_id }, reservationDTO);

        }


        //Delete
        [HttpDelete]
        [Route("{id:guid}")]
      
       // [Authorize(Roles = "receptionist,manager")]
        public async Task<IActionResult> DeleteReservationAsync(Guid id)
        {
            //Get  from database 

            var reservation = await _reservatioRepository.DeleteAsync(id);


            //if null not found
            if (reservation == null)
            {
                return NotFound();
            }
            //convert response back to DTO
            var reservationDTO = new Model.DTO.Reservation
            {
                reservation_id = reservation.reservation_id,

                no_of_adults = reservation.no_of_adults,

                no_of_children = reservation.no_of_children,

                Check_out = reservation.Check_out,

                Check_in = reservation.Check_in,

                status = reservation.status,

                no_of_nights = reservation.no_of_adults,

                Guest_Id = reservation.Guest_Id,

                Room_id = reservation.Room_id
            };

            //return Ok response
            return Ok(reservationDTO);

        }


        //Update
        [HttpPut]
        [Route("{id:guid}")]
        
          //[Authorize(Roles = "receptionist,manager,owner")]
        public async Task<IActionResult> UpdateReservationAsync([FromRoute] Guid id, [FromBody] Model.DTO.UpdateReservationRequest updatereservationRequest)
        {
            

            var reservation = new Model.Domain.Reservation()
            {

                no_of_adults = updatereservationRequest.no_of_adults,

                no_of_children = updatereservationRequest.no_of_children,

                Check_out = updatereservationRequest.Check_out,

                Check_in = updatereservationRequest.Check_in,

                status = updatereservationRequest.status,

                no_of_nights = updatereservationRequest.no_of_nights,

                Guest_Id = updatereservationRequest.Guest_Id,

                Room_id = updatereservationRequest.Room_id,

              };


            //update using repository
            reservation = await _reservatioRepository.UpdateAsync(id, reservation);

            //if null not found
            if (reservation == null)
            {
                return NotFound();
            }

            //Convert Domain back to DTO
            var reservationDTO = new Model.DTO.Reservation
            {
                no_of_adults = reservation.no_of_adults,

                no_of_children = reservation.no_of_children,

                Check_out = reservation.Check_out,

                Check_in = reservation.Check_in,

                status = reservation.status,

                no_of_nights = reservation.no_of_nights,

                Guest_Id = reservation.Guest_Id,

                Room_id = reservation.Room_id

                 };

           

            return Ok(reservationDTO);
        }


       
    }
}

