﻿using AutoMapper;
using HotelManagement_Project.Model.DTO;
using HotelManagement_Project.Repositories;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace HotelManagement_Project.Controllers
{

    [ApiController]
    [Route("Room")]
    public class RoomController : Controller

    {
        private readonly IRoomRepository _roomRepository;
        private readonly IMapper Mapper;

        //constructor
        public RoomController(IRoomRepository roomRepository, IMapper mapper)
        {
            this._roomRepository = roomRepository;

            this.Mapper = mapper;
        }


        //GetAll
        [HttpGet]
      
        // [Authorize(Roles = "receptionist,manager,owner")]
        public async Task<IActionResult> GetAllRoomAsync()
        {
            var room = await _roomRepository.GetAllAsync();

            //BY using Auto MApper

            var roomDTO = Mapper.Map<List<Model.DTO.Room>>(room);

            return Ok(roomDTO);
        }


        //GetByID
        [HttpGet]
        [Route("{id:guid}")]
        [ActionName("GetRoomAsync")]
       
        //[Authorize(Roles = "manager,owner")]
        public async Task<IActionResult> GetRoomAsync(Guid id)
        {
            var room = await _roomRepository.GetAsync(id);

            if (room == null)
            {
                return NotFound();
            }

            var roomDTO = Mapper.Map<Model.DTO.Room>(room);

            return Ok(roomDTO);
        }

        //Add
        [HttpPost]
       
        //[Authorize(Roles = "manager,owner")]
        public async Task<IActionResult> AddRoomAsync(Model.DTO.AddRoomRequest addRoomRequest)
        {
            var room = new Model.Domain.Room()
            {
                room_rate = addRoomRequest.room_rate,

                room_status = addRoomRequest.room_status,

            };

            //Pass details to Repository
            room = await _roomRepository.AddAsync(room);

            //Convert back to DTO

            var roomDTO = new Model.DTO.Room
            {
                room_rate = room.room_rate,

                room_status = room.room_status,

            };

            return CreatedAtAction(nameof(GetRoomAsync), new { id = roomDTO.room_id }, roomDTO);

        }


        //Delete
        [HttpDelete]
        [Route("{id:guid}")]
        
        //[Authorize(Roles = "manager,owner")]
        public async Task<IActionResult> DeleteRoomAsync(Guid id)
        {
           

            var room = await _roomRepository.DeleteAsync(id);


            
            if (room == null)
            {
                return NotFound();
            }
            //convert response back to DTO
            var roomDTO = new Model.DTO.Room
            {
                room_rate = room.room_rate,

                room_status = room.room_status

            };

           
            return Ok(roomDTO);

        }


        //Update
        [HttpPut]
        [Route("{id:guid}")]
       
        //[Authorize(Roles = "manager,owner")]
        public async Task<IActionResult> UpdateRoomAsync([FromRoute] Guid id, [FromBody] Model.DTO.UpdateRoomRequest updateroomRequest)
        {
            

            var room = new Model.Domain.Room()
            {
                room_rate = updateroomRequest.room_rate,

                room_status = updateroomRequest.room_status

            };


            //update  using repository
            room = await _roomRepository.UpdateAsync(id, room);

            
            if (room == null)
            {
                return NotFound();
            }

            //Convert Domain back to DTO
            var roomDTO = new Model.DTO.Room
            {
                room_rate = room.room_rate,

                room_status = room.room_status

            };

          

            return Ok(roomDTO);
        }


        
    }
}
