﻿using AutoMapper;
using HotelManagement_Project.Model.Domain;
using HotelManagement_Project.Model.DTO;
using HotelManagement_Project.Repositories;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Microsoft.EntityFrameworkCore.Infrastructure;
using System.Data;

namespace HotelManagement_Project.Controllers
{

    [ApiController]

    [Route("Guest")]
    
    public class GuestController : Controller
    {
        private readonly IGuestRepository _guestRepository;
        private readonly IMapper Mapper;

        //constructor
        public GuestController(IGuestRepository guestRepository, IMapper mapper)
        {
            this._guestRepository = guestRepository;

            this.Mapper = mapper;
        }


        //GetAll
        [HttpGet]
        
        public async Task<IActionResult> GetAllGuestAsync()
        {
            var guest = await _guestRepository.GetAllAsync();

            // Auto MApper
           
            var guestsDTO = Mapper.Map<List<Model.DTO.Guest>>(guest);




            return Ok(guestsDTO);
        }


        //GetByID
        [HttpGet]
        [Route("{id:Guid}")]
        [ActionName("GetGuestAsync")]
        
       // [Authorize(Roles = "receptionist")]
        public async Task<IActionResult> GetGuestAsync(Guid id)
        {
            var guestm = await _guestRepository.GetAsync(id);

            if (guestm == null)
            {
                return NotFound();
            }

            var guestDTO = Mapper.Map<Model.DTO.Guest>(guestm);

            return Ok(guestDTO);
        }


        //GetByID
        [HttpPost]
        
        //[Authorize(Roles = "receptionist")]
        public async Task<IActionResult> AddGuestAsync(Model.DTO.AddGuestRequest addguestRequest)
        {
            //adding Validation to the request
           //if(!(await ValidateAddGuestAsync(addguestRequest)))
           // {
           //     return BadRequest(ModelState);
           // }
            // first convert Request(DTO) to domain model
            var guest = new Model.Domain.Guest()
            {
                E_mail = addguestRequest.E_mail,
                Guest_Name = addguestRequest.Guest_Name,
                Gender = addguestRequest.Gender,
                Address = addguestRequest.Address,
                Phone_number = addguestRequest.Phone_number

            };

            //Pass details to Repository
            guest = await _guestRepository.AddAsync(guest);

            //domain to DTO

            var guestDTO = new Model.DTO.Guest
            {
                Guest_id = guest.Guest_id,
                E_mail = guest.E_mail,
                Guest_Name = guest.Guest_Name,
                Gender = guest.Gender,
                Address = guest.Address,
                Phone_number = guest.Phone_number

            };

            return CreatedAtAction(nameof(GetGuestAsync), new { id = guestDTO.Guest_id }, guestDTO);

        }


        //Delete
        [HttpDelete]
        [Route("{id:guid}")]
        [ActionName("DeleteGuestAsync")]
       
        public async Task<IActionResult> DeleteGuestAsync(Guid id)
        {
            //Get region from database 

            var guest = await _guestRepository.DeleteAsync(id);

            //if null not found
            if (guest == null)
            {
                return NotFound();
            }
            //convert response back to DTO
            var guestDTO = new Model.DTO.Guest
            {
                Guest_id = guest.Guest_id,
                E_mail = guest.E_mail,
                Guest_Name = guest.Guest_Name,
                Gender = guest.Gender,
                Address = guest.Address,
                Phone_number = guest.Phone_number

            };

            //return Ok response
            return Ok(guestDTO);

        }


        //Update
        [HttpPut]
        [Route("{id:guid}")]
        [ActionName("UpdateGuestAsync")]
       
        public async Task<IActionResult> UpdateGuestAsync([FromRoute] Guid id, 
            [FromBody] Model.DTO.UpdateGuestRequest updateguestRequest)
        {
            
            var guest = new Model.Domain.Guest()
            {
                E_mail = updateguestRequest.E_mail,
                Guest_Name = updateguestRequest.Guest_Name,
                Gender = updateguestRequest.Gender,
                Address = updateguestRequest.Address,
                Phone_number = updateguestRequest.Phone_number
            };


            //update region using repository
            guest = await _guestRepository.UpdateAsync(id, guest);

            //if null not found
            if (guest == null)
            {
                return NotFound();
            }

            //Convert Domain back to DTO
            var guestDTO = new Model.DTO.Guest
            {
                Guest_id = guest.Guest_id,
                E_mail = guest.E_mail,
                Guest_Name = guest.Guest_Name,
                Gender = guest.Gender,
                Address = guest.Address,
                Phone_number = guest.Phone_number

            };

            //Return OK Response

            return Ok(guestDTO);
        }


        

    }
}


