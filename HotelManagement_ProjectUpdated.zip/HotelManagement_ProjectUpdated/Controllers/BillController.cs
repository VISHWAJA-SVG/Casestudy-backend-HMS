﻿using AutoMapper;
using HotelManagement_Project.Model.DTO;
using HotelManagement_Project.Repositories;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PdfSharpCore;
using PdfSharpCore.Pdf;
using TheArtOfDev.HtmlRenderer.PdfSharp;
namespace HotelManagement_Project.Controllers
{
    

[ApiController]
[Route("Bill")]
 
    public class BillController : Controller
  {
        private readonly IBillRepository _billRepository;
        private readonly IMapper Mapper;
        private readonly IRoomRepository roomRepository;
        private readonly IReservationRepository reservationRepository;

        //constructor
        public BillController(IBillRepository billRepository, IMapper mapper, 
            IRoomRepository roomRepository, IReservationRepository reservationRepository)
    {
        this._billRepository = billRepository;

        this.Mapper = mapper;

        this.roomRepository = roomRepository;      
            
        this.reservationRepository = reservationRepository;
        }

        //GetAll
    [HttpGet]
      
        public async Task<IActionResult> GetAllBillAsync()
    {
        var bill = await _billRepository.GetAllAsync();

        // Auto MApper

        var billsDTO = Mapper.Map<List<Model.DTO.Bill>>(bill);

        return Ok(billsDTO);
    }
         
        
        //GetByID
    [HttpGet]
    [Route("{id:guid}")]
    [ActionName("GetBillAsync")]
     
        public async Task<IActionResult> GetBillAsync(Guid id)
    {
        var billm = await _billRepository.GetAsync(id);

        if (billm == null)
        {
            return NotFound();
        }

        var billDTO = Mapper.Map<Model.DTO.Bill>(billm);

        return Ok(billDTO);
    }


        //Add
    [HttpPost]
       
        public async Task<IActionResult> AddBillAsync(Model.DTO.AddBillRequest addbillRequest)
    {
           

            //  convert Request(DTO) to domain model
            var bill = new Model.Domain.Bill()
        {

            stay_dates = addbillRequest.stay_dates,

            total_bill = addbillRequest.total_bill,

            Room_id = addbillRequest.Room_id,

            Reservation_id = addbillRequest.Reservation_id,

        };

        //Pass details to Repository
        bill = await _billRepository.AddAsync(bill);

        //Convert back to DTO

        var billDTO = new Model.DTO.Bill()
        {

            stay_dates = addbillRequest.stay_dates,

            total_bill = addbillRequest.total_bill,

            Room_id = addbillRequest.Room_id,

            Reservation_id = addbillRequest.Reservation_id,

        };

        return CreatedAtAction(nameof(GetBillAsync), new { id = billDTO.Bill_id }, billDTO);

    }


        //Delete
    [HttpDelete]
    [Route("{id:guid}")]
       
        public async Task<IActionResult> DeleteBillAsync(Guid id)
    {
        //Get  from database 

        var bill = await _billRepository.DeleteAsync(id);

        
        if (bill == null)
        {
            return NotFound();
        }
        //domain to DTO
        var billDTO = new Model.DTO.Bill
        {
            stay_dates = bill.stay_dates,

            total_bill = bill.total_bill,

            Room_id = bill.Room_id,

            Reservation_id = bill.Reservation_id,
        };

        return Ok(billDTO);

    }


        //Update
    [HttpPut]
    [Route("{id:guid}")]
    //[Authorize(Roles = "receptionist,manager,owner")]
    public async Task<IActionResult> UpdateBillAsync([FromRoute] Guid id, 
    [FromBody] Model.DTO.UpdateBillRequest updatebillRequest)
        {


            var bill = new Model.Domain.Bill()
         {
            stay_dates = updatebillRequest.stay_dates,

            total_bill = updatebillRequest.total_bill,

            Room_id = updatebillRequest.Room_id,

            Reservation_id = updatebillRequest.Reservation_id,

        };


        //update using repository
        bill = await _billRepository.UpdateAsync(id, bill);

        
        if (bill == null)
        {
            return NotFound();
        }

        //Convert Domain to DTO
        var billDTO = new Model.DTO.Bill
        {
            stay_dates = bill.stay_dates,

            total_bill = bill.total_bill,

            Room_id = bill.Room_id,

            Reservation_id = bill.Reservation_id

        };
        return Ok(billDTO);
    }  

//code for pdf generation

    [HttpGet("generatepdf")]
        public async Task<IActionResult> GeneratePDF(Guid id)
        {
            var document = new PdfDocument();
            string HtmlContent = "<h1  style=\"text-align: center;\">Welcome to Carnival Hotel</h1>";
             HtmlContent += "<p style=\"text-align: center;\">1/187,Airoli,Navi Mumbai-560037,Maharashtra</p>";
            var header = await _billRepository.GetAsync(id);
           
        
           if (header != null)
{
  HtmlContent += "<table style=\"width: 100%; table-layout: fixed; border-collapse: collapse;\">";
  HtmlContent += "<tr><th style=\"border: 1px solid black;\">Bill_id</th><th style=\"border: 1px solid black;\">stay_dates</th><th style=\"border: 1px solid black;\">total_bill</th></tr>";
  HtmlContent += "<tr>";
  HtmlContent += "<td style=\"border: 1px solid black; text-align: center; word-wrap: break-word;\">" + header.Bill_id + "</td>";
  HtmlContent += "<td style=\"border: 1px solid black; text-align: center; word-wrap: break-word;\">" + header.stay_dates + "</td>";
  HtmlContent += "<td style=\"border: 1px solid black; text-align: center; word-wrap: break-word;\">" + header.total_bill + "</td>";
  HtmlContent += "</tr>";
  HtmlContent += "</table>";
  HtmlContent += "<p>Please Deposit Room Key Card</p>";
  HtmlContent += "<p>Thank You, Visit Again</p>";
}

            PdfGenerator.AddPdfPages(document, HtmlContent, PageSize.A4);

            byte[] response = null;
            using(MemoryStream ms = new MemoryStream())
            {
                document.Save(ms);
                //PdfGenerator.GeneratePdf(HtmlContent, PdfSharp.PageSize.A4,60);
                response = ms.ToArray();
            }
            string Filename = "Bill_" + id + ".pdf";
            return File(response, "application/pdf", Filename);
        }
       
    }


    }


