namespace HotelManagement_Project.Model.DTO
{
    public class UpdateGuestRequest
    {
        public string E_mail { get; set; }

        public string Guest_Name { get; set; }

        public string Gender { get; set; }

        public string Address { get; set; }

        public long Phone_number { get; set; }
    }
}
