namespace HotelManagement_Project.Model.DTO
{
    public class AddInventoryRequest
    {
        public string Inventory_Name { get; set; }

        public int quantity { get; set; }

        
    }
}
