namespace HotelManagement_Project.Model.DTO
{
    public class UpdateInventoryRequest
    {
        public string Inventory_Name { get; set; }

        public int quantity { get; set; }
    }
}
