﻿using AutoMapper;

namespace HotelManagement_Project.Profiles
{
    public class ReservationProfil : Profile
    {
        public ReservationProfil()
        {
            CreateMap<Model.Domain.Reservation,Model.DTO.Reservation>().ReverseMap();
        }
    }
}
