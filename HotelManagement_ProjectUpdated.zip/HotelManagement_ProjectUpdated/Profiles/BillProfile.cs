﻿using AutoMapper;

namespace HotelManagement_Project.Profiles
{
    public class BillProfile: Profile
    {
        public BillProfile()
        {
          
            CreateMap<Model.Domain.Bill, Model.DTO.Bill>().ReverseMap();
            
        }
    }
}
