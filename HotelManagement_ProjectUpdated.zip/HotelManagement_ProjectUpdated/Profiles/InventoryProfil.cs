﻿using AutoMapper;

namespace HotelManagement_Project.Profiles
{
    public class InventoryProfil : Profile
    {
        public InventoryProfil()
        {
         
                CreateMap<Model.Domain.Inventory, Model.DTO.Inventory>().ReverseMap();
            
        }
    }
}
