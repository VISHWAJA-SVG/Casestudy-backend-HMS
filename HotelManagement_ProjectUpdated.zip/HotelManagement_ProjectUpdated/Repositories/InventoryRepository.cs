﻿using HotelManagement_Project.Model.Domain;
using Microsoft.EntityFrameworkCore;
using HotelManagement_Project.Data;

namespace HotelManagement_Project.Repositories
{
    public class InventoryRepository : IInventoryRepositorycs
    {
        
        private readonly AbcDbContext _db;
        public InventoryRepository(AbcDbContext db)
        {
            _db = db;
        }

        //add method
        public async Task<Inventory> AddAsync(Inventory inventory)
        {
            inventory.Inventory_Id = Guid.NewGuid();

            await _db.AddAsync(inventory);

            await _db.SaveChangesAsync();

            return inventory;

        }


        // delete by id
        public async Task<Inventory> DeleteAsync(Guid id)

        {
            var inventory = await _db.Inventories.FirstOrDefaultAsync(x => x.Inventory_Id == id);


            if (inventory == null)
            {
                return null;
            }
            //Delete 
            _db.Inventories.Remove(inventory);

            await _db.SaveChangesAsync();

            return inventory;

        }

        //list all things
        public async Task<IEnumerable<Inventory>> GetAllAsync()
        {
            return await _db.Inventories.ToListAsync();

        }
        public async Task<Inventory> GetAsync(Guid id)
        {
            return await _db.Inventories.FirstOrDefaultAsync(x => x.Inventory_Id == id);


        }
        public async Task<Inventory> UpdateAsync(Guid id, Inventory inventory)
        {
            //check if id exists

            var existinginventory = await _db.Inventories.FirstOrDefaultAsync(x => x.Inventory_Id == id);

            if (existinginventory == null)
            {
                return null;
            }

            // id not updated

            existinginventory.Inventory_Name = inventory.Inventory_Name;

            existinginventory.quantity = inventory.quantity;

            await _db.SaveChangesAsync();

            return existinginventory;

        }

    }
}




