﻿using HotelManagement_Project.Model.Domain;

namespace HotelManagement_Project.Repositories
{
    public interface IUserRepository
    {
        Task<Staff> AuthenticateAsync(string username, string password);
    }
}
