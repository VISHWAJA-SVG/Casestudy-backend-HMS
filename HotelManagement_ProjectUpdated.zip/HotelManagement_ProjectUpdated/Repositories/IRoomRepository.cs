﻿using HotelManagement_Project.Model.Domain;

namespace HotelManagement_Project.Repositories
{
    public interface IRoomRepository
    {
        Task<IEnumerable<Room>> GetAllAsync();
       
//goes to repository class
        Task<Room> GetAsync(Guid id);

        Task<Room> AddAsync(Room room);

        Task<Room> DeleteAsync(Guid id);

        Task<Room> UpdateAsync(Guid id, Room room);
    }
}
