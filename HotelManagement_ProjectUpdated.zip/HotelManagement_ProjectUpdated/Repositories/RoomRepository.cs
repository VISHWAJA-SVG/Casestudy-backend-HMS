﻿using HotelManagement_Project.Model.Domain;
using Microsoft.EntityFrameworkCore;
using HotelManagement_Project.Data;

namespace HotelManagement_Project.Repositories
{
    public class RoomRepository:IRoomRepository
    {
        
        private readonly AbcDbContext _db;
        public RoomRepository(AbcDbContext db)
        {
            _db = db;
        }

        
        public async Task<Room> AddAsync(Room room)
        {
            room.room_id = Guid.NewGuid();

            await _db.AddAsync(room);

            await _db.SaveChangesAsync();

            return room;

        }


        // delete by id
        public async Task<Room> DeleteAsync(Guid id)

        {
            var room = await _db.Rooms.FirstOrDefaultAsync(x => x.room_id == id);


            if (room == null)
            {
                return null;
            }
            //Delete 
            _db.Rooms.Remove(room);

            await _db.SaveChangesAsync();

            return room;

        }

        //list all things
        public async Task<IEnumerable<Room>> GetAllAsync()
        {
            return await _db.Rooms.ToListAsync();

        }
        public async Task<Room> GetAsync(Guid id)
        {
            return await _db.Rooms.FirstOrDefaultAsync(x => x.room_id == id);


        }
        public async Task<Room> UpdateAsync(Guid id, Room room)
        {
            //find if id exist

            var existingroom = await _db.Rooms.FirstOrDefaultAsync(x => x.room_id == id);

            if (existingroom == null)
            {
                return null;
            }

            // here we are updating the all value except id becauses it will remain same

            existingroom.room_status = room.room_status;

            existingroom.room_rate = room.room_rate;

            await _db.SaveChangesAsync();

            return existingroom;

        }

    }
}


