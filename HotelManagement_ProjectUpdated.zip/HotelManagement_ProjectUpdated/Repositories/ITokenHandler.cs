﻿using HotelManagement_Project.Model.Domain;

namespace HotelManagement_Project.Repositories
{
    public interface ITokenHandler
    {
        Task<string> CreateTokenAsync(Staff user);
    }
}
