﻿using HotelManagement_Project.Model.Domain;
using Microsoft.EntityFrameworkCore;
using HotelManagement_Project.Data;

namespace HotelManagement_Project.Repositories
{
    public class GuestRepository : IGuestRepository

    {
        
        private readonly AbcDbContext _db;
        public GuestRepository(AbcDbContext db)
        {
            _db = db;
        }

        // add guest 
        public async Task<Guest> AddAsync(Guest guest)
        {
            guest.Guest_id = Guid.NewGuid();

            await _db.AddAsync(guest);

            await _db.SaveChangesAsync();

            return guest;

        }


        //  delete by id 
        public async Task<Guest> DeleteAsync(Guid id)

        {
            var guest = await _db.Guests.FirstOrDefaultAsync(x => x.Guest_id == id);


            if (guest == null)
            {
                return null;
            }
            //Delete the guest
            _db.Guests.Remove(guest);

            await _db.SaveChangesAsync();

            return guest;

        }

        //here it will show all things
        public async Task<IEnumerable<Guest>> GetAllAsync()
        {
            return await _db.Guests.ToListAsync();

        }
        public async Task<Guest> GetAsync(Guid id)
        {
            return await _db.Guests.FirstOrDefaultAsync(x => x.Guest_id == id);


        }
        public async Task<Guest> UpdateAsync(Guid id, Guest guest)
        {
            //check for id

            var existingguest = await _db.Guests.FirstOrDefaultAsync(x => x.Guest_id == id);

            if (existingguest == null)
            {
                return null;
            }

            // id not updated

            existingguest.E_mail = guest.E_mail;

            existingguest.Guest_Name = guest.Guest_Name;

            existingguest.Address = guest.Address;

            existingguest.Gender = guest.Gender;

            existingguest.Phone_number = guest.Phone_number;

            await _db.SaveChangesAsync();

            return existingguest;

        }

    }
}

