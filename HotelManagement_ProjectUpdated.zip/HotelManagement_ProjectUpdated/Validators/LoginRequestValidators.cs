﻿using FluentValidation;

namespace HotelManagement_Project.Validators
{
    public class LoginRequestValidators: AbstractValidator<Model.DTO.LoginRequest>
    {
        public LoginRequestValidators()
        {
            RuleFor(x=>x.UserName).NotEmpty();  

            RuleFor(x=>x.Password).NotEmpty();  
        }
    }
}
